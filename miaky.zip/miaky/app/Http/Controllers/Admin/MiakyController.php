<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Miaky;
use Illuminate\Http\Request;
use Session;

class MiakyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $keyword = $request->get('search');
        $perPage = 25;

        if (!empty($keyword)) {
            $miaky = Miaky::where('title', 'LIKE', "%$keyword%")
				->orWhere('category', 'LIKE', "%$keyword%")
				->orWhere('partner', 'LIKE', "%$keyword%")
				->orWhere('Description', 'LIKE', "%$keyword%")
				->orWhere('Publish', 'LIKE', "%$keyword%")
				->orWhere('price', 'LIKE', "%$keyword%")
				->orWhere('Feature', 'LIKE', "%$keyword%")
				->orWhere('Discount', 'LIKE', "%$keyword%")
				->orWhere('File', 'LIKE', "%$keyword%")
				->orWhere('Thambnail', 'LIKE', "%$keyword%")
				
                ->paginate($perPage);
        } else {
            $miaky = Miaky::paginate($perPage);
        }

        return view('admin.miaky.index', compact('miaky'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('admin.miaky.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
        
        $requestData = $request->all();
        

if ($request->hasFile('File')) {
    $uploadPath = public_path('/uploads/');

    $extension = $request->file('File')->getClientOriginalExtension();
    $fileName = rand(11111, 99999) . '.' . $extension;

    $request->file('File')->move($uploadPath, $fileName);
    $requestData['File'] = $fileName;
}


if ($request->hasFile('Thambnail')) {
    $uploadPath = public_path('/uploads/');

    $extension = $request->file('Thambnail')->getClientOriginalExtension();
    $fileName = rand(11111, 99999) . '.' . $extension;

    $request->file('Thambnail')->move($uploadPath, $fileName);
    $requestData['Thambnail'] = $fileName;
}

        Miaky::create($requestData);

        Session::flash('flash_message', 'Miaky added!');

        return redirect('admin/miaky');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $miaky = Miaky::findOrFail($id);

        return view('admin.miaky.show', compact('miaky'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $miaky = Miaky::findOrFail($id);

        return view('admin.miaky.edit', compact('miaky'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update($id, Request $request)
    {
        
        $requestData = $request->all();
        

if ($request->hasFile('File')) {
    $uploadPath = public_path('/uploads/');

    $extension = $request->file('File')->getClientOriginalExtension();
    $fileName = rand(11111, 99999) . '.' . $extension;

    $request->file('File')->move($uploadPath, $fileName);
    $requestData['File'] = $fileName;
}


if ($request->hasFile('Thambnail')) {
    $uploadPath = public_path('/uploads/');

    $extension = $request->file('Thambnail')->getClientOriginalExtension();
    $fileName = rand(11111, 99999) . '.' . $extension;

    $request->file('Thambnail')->move($uploadPath, $fileName);
    $requestData['Thambnail'] = $fileName;
}

        $miaky = Miaky::findOrFail($id);
        $miaky->update($requestData);

        Session::flash('flash_message', 'Miaky updated!');

        return redirect('admin/miaky');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        Miaky::destroy($id);

        Session::flash('flash_message', 'Miaky deleted!');

        return redirect('admin/miaky');
    }
}
