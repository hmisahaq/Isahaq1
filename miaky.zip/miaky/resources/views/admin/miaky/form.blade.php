{!! Html::style('/css/bootstrap.min.css')!!}

{!! Html::script('/js/bootstrap.min.js') !!} 
 <table>
<tr>
<td>
<div class="form-group {{ $errors->has('title') ? 'has-error' : ''}}">
    {!! Form::label('title', 'Title', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::text('title', null, ['class' => 'form-control','placeholder'=>'Product Title']) !!}
        {!! $errors->first('title', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('category') ? 'has-error' : ''}}">
    {!! Form::label('category', 'Category', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::select('category', array('Video'=>'Video','Audio'=>'Audio','Image'=>'Image'), null, ['class' => 'form-control']) !!}
        {!! $errors->first('category', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('partner') ? 'has-error' : ''}}">
    {!! Form::label('partner', 'Partner', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::select('partner', array('Spondon'=>'Spondon','SSl'=>'SSl'), null, ['class' => 'form-control']) !!}
        {!! $errors->first('partner', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('Description') ? 'has-error' : ''}}">
    {!! Form::label('Description', 'Description', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::textarea('Description', null, ['class' => 'form-control','placeholder'=>'Product Descriptions','style'=>'height:150px; width:215px']) !!}
        {!! $errors->first('Description', '<p class="help-block">:message</p>') !!}
    </div>
</div>
</td>
<td>
<div class="form-group {{ $errors->has('Publish') ? 'has-error' : ''}}">
    {!! Form::label('Publish', 'Publish', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::radio('Publish', 'Yes', ['class' => 'form-control']) !!}Yes
		{!! Form::radio('Publish', 'No', ['class' => 'form-control']) !!}No
        {!! $errors->first('Publish', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('price') ? 'has-error' : ''}}">
    {!! Form::label('price', 'Price', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::text('price', null, ['class' => 'form-control']) !!}
        {!! $errors->first('price', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('File') ? 'has-error' : ''}}">
    {!! Form::label('File', 'File', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::file('File', null, ['class' => 'form-control']) !!}
        {!! $errors->first('File', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('Thambnail') ? 'has-error' : ''}}">
    {!! Form::label('Thambnail', 'Thambnail', ['class' => 'col-md-4 control-label']) !!}
	
    <div class="col-md-6">
        {!! Form::file('Thambnail', null, ['class' => 'form-control']) !!}
        {!! $errors->first('Thambnail', '<p class="help-block">:message</p>') !!}
    </div>
</div>



<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        {!! Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']) !!}
  
	</div>
</div>
</td>
<td><div class="form-group {{ $errors->has('Feature') ? 'has-error' : ''}}">
    {!! Form::label('Feature', 'Feature', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::radio('Feature','Yes', ['class' => 'form-control'])!!}Yes
        {!! Form::radio('Feature','No', ['class' => 'form-control'])!!}No
		
        {!! $errors->first('Feature', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('Discount') ? 'has-error' : ''}}">
    {!! Form::label('Discount', 'Discount', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::text('Discount', null, ['class' => 'form-control']) !!}
        {!! $errors->first('Discount', '<p class="help-block">:message</p>%') !!}
    </div>
</div>

<img src=""  style="height:100px; width:100px" alt="images/camera.jpg">

</td>
<tr>
</table>